import { FormEvent, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  connectAccount,
  disconnectAccount,
  fetchAccount,
  type AccountPublic,
} from "../lib/api";
import { writeSession } from "../lib/session";

export function AccountPage() {
  const navigate = useNavigate();
  const [account, setAccount] = useState<AccountPublic | null>(null);
  const [cookie, setCookie] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetchAccount().then(setAccount).catch((err) => {
      setError(err instanceof Error ? err.message : String(err));
    });
  }, []);

  async function onConnect(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const next = await connectAccount(cookie);
      setAccount(next);
      setCookie("");
      writeSession(next.displayName || next.username || "creator");
      navigate("/painel/dashboard", { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function onDisconnect() {
    setBusy(true);
    setError(null);
    try {
      await disconnectAccount();
      navigate("/", { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="desk desk-settings gate">
      <p className="desk-kicker">Required</p>
      <h1 className="desk-title">Connect to open the desk</h1>
      <p className="desk-sub">
        Dashboard, feed, and upload stay locked until you paste{" "}
        <strong>your own</strong> Roblox <code>.ROBLOSECURITY</code>. Never paste
        someone else’s session. Stored only in local <code>farol/data/</code> —
        not sent to Discord.
      </p>

      {account?.connected ? (
        <div className="dash-panel" style={{ marginTop: 24 }}>
          <p className="kpi-label">Connected</p>
          <p className="kpi-value">{account.displayName || account.username}</p>
          <p className="desk-sub">
            @{account.username} · id {account.userId}
          </p>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={onDisconnect}
            disabled={busy}
            style={{ marginTop: 16 }}
          >
            Disconnect
          </button>
        </div>
      ) : (
        <form onSubmit={onConnect} className="desk-panel">
          <label className="desk-field">
            <span>Your .ROBLOSECURITY</span>
            <textarea
              value={cookie}
              onChange={(event) => setCookie(event.target.value)}
              autoComplete="off"
              spellCheck={false}
              rows={5}
              placeholder="_|WARNING:-DO-NOT-SHARE-THIS.--..."
              className="account-cookie"
            />
          </label>
          <p className="desk-sub">
            Browser → roblox.com → DevTools → Application → Cookies → copy the
            value of <code>.ROBLOSECURITY</code> from your logged-in profile.
          </p>
          <button type="submit" className="btn btn-solid" disabled={busy || !cookie.trim()}>
            {busy ? "Checking…" : "Connect my account"}
          </button>
        </form>
      )}

      {error && <p className="desk-error">{error}</p>}
    </div>
  );
}
