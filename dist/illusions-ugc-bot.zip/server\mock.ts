import type { CatalogItem } from "./types.js";

const NOW = Date.now();

function item(
  id: number,
  name: string,
  creatorId: number,
  creatorName: string,
  category: CatalogItem["category"],
  hoursAgo: number,
  saleCount: number | null = null
): CatalogItem {
  const favoriteCount = Math.max(0, 40 - hoursAgo);
  return {
    id,
    itemType: category === "characters" ? "Bundle" : "Asset",
    assetType: category === "shirts" ? 11 : category === "pants" ? 12 : category === "tshirts" ? 2 : null,
    name,
    creatorId,
    creatorName,
    createdAt: new Date(NOW - hoursAgo * 3600_000).toISOString(),
    favoriteCount,
    price: 75,
    category,
    thumbnailUrl: null,
    saleCount,
    demandField: (saleCount || 0) > 0 ? "vendas" : "favoritos",
  };
}

export const MOCK_NOTE =
  "Local sample — the public catalog did not respond. These cards only keep the desk from being empty.";

export function mockCatalogItems(): CatalogItem[] {
  return [
    item(101, "Blue Lock Isagi Jersey Black", 1, "atelier norte", "shirts", 2, 48),
    item(102, "Blue Lock Bachira Street Shirt", 2, "oficina lima", "shirts", 3, 31),
    item(103, "Blue Lock Rin Itoshi Training", 3, "estudio vale", "shirts", 4, 22),
    item(104, "Blue Lock Nagi Seishiro Fit", 1, "atelier norte", "shirts", 5, 18),
    item(105, "Blue Lock Kaiser Pink Shirt", 4, "casa pixel", "shirts", 6, 11),
    item(106, "Blue Lock Chigiri Speed Tee", 5, "linha clara", "tshirts", 7, 9),
    item(107, "Calca Cargo Y2K Star Pocket", 6, "corte urbano", "pants", 3),
    item(108, "Y2K Star Cargo Purple", 7, "rua baixa", "pants", 4),
    item(109, "Y2K Butterfly Cargo Pants", 6, "corte urbano", "pants", 8),
    item(110, "Y2K Star Mini Charm Pants", 8, "oficina lima", "pants", 9),
    item(111, "Solo Leveling Sung Jinwoo Coat Shirt", 9, "noite tinta", "shirts", 2),
    item(112, "Solo Leveling Shadow Army Tee", 10, "estudio vale", "tshirts", 3),
    item(113, "Solo Leveling Ant King Shirt", 9, "noite tinta", "shirts", 5),
    item(114, "Solo Leveling Tank Statue Shirt", 11, "farol studio", "shirts", 6),
    item(115, "Sanrio Kuromi Bow Cute Shirt", 12, "doce loft", "shirts", 4),
    item(116, "Kuromi Purple Star Tee", 13, "casa pixel", "tshirts", 6),
    item(117, "My Melody Sanrio Picnic Shirt", 12, "doce loft", "shirts", 8),
    item(118, "Labubu Forest Spirit Shirt", 14, "atelier norte", "shirts", 1),
    item(119, "Labubu Keychain Street Tee", 15, "linha clara", "tshirts", 2),
    item(120, "Labubu Pink Plush Shirt", 14, "atelier norte", "shirts", 3),
    item(121, "Plain Black Work Shirt", 16, "basico br", "shirts", 20, 0),
    item(122, "Donation Thank You Tee", 17, "basico br", "tshirts", 22, 0),
    item(123, "Random Numbers 9981 Shirt", 18, "avulso", "shirts", 18, 0),
    item(124, "Gojo Satoru Blindfold Shirt", 19, "noite tinta", "shirts", 2),
    item(125, "Jujutsu Kaisen Gojo Domain Tee", 20, "estudio vale", "tshirts", 3),
    item(126, "Gojo Purple Hollow Shirt", 19, "noite tinta", "shirts", 4),
    item(127, "Sukuna Jujutsu Marks Pants", 21, "corte urbano", "pants", 5),
    item(128, "Jujutsu Kaisen First Years Shirt", 4, "casa pixel", "shirts", 7),
    item(129, "Character Bundle Blue Lock Isagi", 22, "bundle lab", "characters", 4),
    item(130, "Character Bundle Sung Jinwoo", 22, "bundle lab", "characters", 5),
    item(131, "Character Bundle Kuromi Cute", 12, "doce loft", "characters", 6),
  ];
}
