import { FormEvent, useEffect, useState } from "react";
import { fetchSettings, saveSettings, type Settings } from "../lib/api";
import { CATEGORY_LABEL, type Category } from "../lib/labels";

export function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchSettings().then(setSettings).catch((err) => {
      setError(err instanceof Error ? err.message : String(err));
    });
  }, []);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!settings) return;
    setError(null);
    try {
      const next = await saveSettings(settings);
      setSettings(next);
      setSaved(true);
      window.setTimeout(() => setSaved(false), 1800);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  function toggleCategory(key: Category) {
    if (!settings) return;
    const exists = settings.categories.includes(key);
    setSettings({
      ...settings,
      categories: exists
        ? settings.categories.filter((item) => item !== key)
        : [...settings.categories, key],
    });
  }

  if (!settings) {
    return <p className="desk-sub">{error || "Loading settings…"}</p>;
  }

  return (
    <form onSubmit={onSubmit} className="desk desk-settings">
      <p className="desk-kicker">Engine</p>
      <h1 className="desk-title">How Illusions scans</h1>
      <p className="desk-sub">
        Continuous scan starts when the server boots. The minimum interval is 10
        minutes — collection is slow on purpose so we do not hammer the public API.
      </p>

      <fieldset className="desk-panel">
        <label className="desk-toggle">
          <span>Continuous scan (default: on)</span>
          <input
            type="checkbox"
            checked={settings.autoScan}
            onChange={(event) =>
              setSettings({ ...settings, autoScan: event.target.checked })
            }
          />
        </label>
        <label className="desk-field">
          <span>Interval (minutes)</span>
          <input
            type="number"
            min={10}
            max={240}
            value={settings.intervalMinutes}
            onChange={(event) =>
              setSettings({ ...settings, intervalMinutes: Number(event.target.value) })
            }
          />
        </label>
        <label className="desk-field">
          <span>Pages per category (1–4)</span>
          <input
            type="number"
            min={1}
            max={4}
            value={settings.pagesPerCategory}
            onChange={(event) =>
              setSettings({ ...settings, pagesPerCategory: Number(event.target.value) })
            }
          />
        </label>
        <div>
          <p className="desk-field-label">Categories</p>
          <div className="cluster-keys">
            {(Object.keys(CATEGORY_LABEL) as Category[]).map((key) => (
              <button
                type="button"
                key={key}
                onClick={() => toggleCategory(key)}
                className={`kw${settings.categories.includes(key) ? " is-on" : ""}`}
              >
                {CATEGORY_LABEL[key]}
              </button>
            ))}
          </div>
        </div>
      </fieldset>

      <fieldset className="desk-panel">
        <h2 className="desk-h2">Discord log</h2>
        <p className="desk-sub">
          Paste your channel webhook. Full desk log: scans, searches, themes,
          uploads, dashboard, settings, downloads. Cookies and images never go
          out. Saving a new URL sends a test message.
        </p>
        <label className="desk-field">
          <span>Webhook URL</span>
          <input
            type="url"
            value={settings.discordWebhook || ""}
            onChange={(event) =>
              setSettings({ ...settings, discordWebhook: event.target.value })
            }
            placeholder={
              settings.discordWebhookSet
                ? "Webhook saved — paste a new one to replace"
                : "https://discord.com/api/webhooks/…"
            }
            autoComplete="off"
          />
        </label>
      </fieldset>

      <fieldset className="desk-panel">
        <h2 className="desk-h2">Desk alert</h2>
        <p className="desk-sub">
          No Telegram in this build. A theme is highlighted in the feed when it
          crosses these numbers.
        </p>
        <label className="desk-field">
          <span>Minimum velocity</span>
          <input
            type="number"
            min={1}
            value={settings.alertMinVelocity}
            onChange={(event) =>
              setSettings({ ...settings, alertMinVelocity: Number(event.target.value) })
            }
          />
        </label>
        <label className="desk-field">
          <span>Minimum acceleration</span>
          <input
            type="number"
            min={0.5}
            step={0.1}
            value={settings.alertMinAcceleration}
            onChange={(event) =>
              setSettings({
                ...settings,
                alertMinAcceleration: Number(event.target.value),
              })
            }
          />
        </label>
        <label className="desk-field">
          <span>Minimum purity</span>
          <input
            type="number"
            min={0}
            max={1}
            step={0.05}
            value={settings.alertMinPurity}
            onChange={(event) =>
              setSettings({ ...settings, alertMinPurity: Number(event.target.value) })
            }
          />
        </label>
      </fieldset>

      {error && <p className="desk-error">{error}</p>}

      <button type="submit" className="btn btn-solid">
        {saved ? "Saved" : "Save settings"}
      </button>
    </form>
  );
}
