import { Navigate, Route, Routes } from "react-router-dom";
import { AccountPage } from "./pages/AccountPage";
import { AppShell } from "./pages/AppShell";
import { ClusterPage } from "./pages/ClusterPage";
import { DashboardPage } from "./pages/DashboardPage";
import { Feed } from "./pages/Feed";
import { Landing } from "./pages/Landing";
import { SettingsPage } from "./pages/SettingsPage";
import { UploadPage } from "./pages/UploadPage";

export function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/painel" element={<AppShell />}>
        <Route index element={<Feed />} />
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="upload" element={<UploadPage />} />
        <Route path="tema/:id" element={<ClusterPage />} />
        <Route path="ajustes" element={<SettingsPage />} />
        <Route path="conta" element={<AccountPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
