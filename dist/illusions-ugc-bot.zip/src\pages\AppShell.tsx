import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Atmosphere } from "../components/Atmosphere";
import { BrandMark, Wordmark } from "../components/Logo";
import { disconnectAccount, fetchAccount } from "../lib/api";
import { clearSession, writeSession } from "../lib/session";
import { useEffect, useState } from "react";

const navClass = ({ isActive }: { isActive: boolean }) =>
  `shell-link${isActive ? " is-active" : ""}`;

export function AppShell() {
  const navigate = useNavigate();
  const location = useLocation();
  const [name, setName] = useState("creator");
  const [ready, setReady] = useState(false);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    let alive = true;
    fetchAccount()
      .then((account) => {
        if (!alive) return;
        setConnected(account.connected);
        if (account.connected) {
          const label = account.displayName || account.username || "creator";
          setName(label);
          writeSession(label);
        }
        setReady(true);
        if (!account.connected && location.pathname !== "/painel/conta") {
          navigate("/painel/conta", { replace: true });
        }
      })
      .catch(() => {
        if (!alive) return;
        setReady(true);
        setConnected(false);
        if (location.pathname !== "/painel/conta") {
          navigate("/painel/conta", { replace: true });
        }
      });
    return () => {
      alive = false;
    };
  }, [location.pathname, navigate]);

  return (
    <div className="shell">
      <Atmosphere variant="desk" />
      <header className="shell-header">
        <div className="shell-header-inner">
          <NavLink
            to={connected ? "/painel/dashboard" : "/painel/conta"}
            className="logo"
            aria-label="Illusions UGC Bot"
          >
            <BrandMark />
            <Wordmark />
          </NavLink>
          {connected ? (
            <nav className="shell-nav" aria-label="Desk">
              <NavLink to="/painel/dashboard" className={navClass}>
                Dashboard
              </NavLink>
              <NavLink to="/painel" end className={navClass}>
                Feed
              </NavLink>
              <NavLink to="/painel/upload" className={navClass}>
                Upload
              </NavLink>
              <NavLink to="/painel/ajustes" className={navClass}>
                Settings
              </NavLink>
            </nav>
          ) : (
            <nav className="shell-nav" aria-label="Desk">
              <span className="shell-link is-active">Account</span>
            </nav>
          )}
          <div className="shell-end">
            {connected ? (
              <NavLink to="/painel/conta" className="shell-account">
                {name}
              </NavLink>
            ) : (
              <span className="shell-account">Cookie required</span>
            )}
            <button
              type="button"
              className="shell-signout"
              onClick={() => {
                void disconnectAccount();
                clearSession();
                navigate("/");
              }}
            >
              Sign out
            </button>
          </div>
        </div>
      </header>
      <div className="shell-main">
        {!ready ? <p className="desk-sub">Checking session…</p> : <Outlet />}
      </div>
    </div>
  );
}
