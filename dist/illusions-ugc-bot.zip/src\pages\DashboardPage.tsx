import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchDashboard, type DashboardData } from "../lib/api";

function robux(n: number): string {
  return `R$ ${Number(n || 0).toLocaleString("en-US")}`;
}

function uptimeLabel(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${h}h ${m}m`;
}

function weekSeries(
  weekly?: { date: string; revenue: number; sales: number }[]
): { date: string; revenue: number; sales: number }[] {
  if (weekly && weekly.length > 0) return weekly;
  const days: { date: string; revenue: number; sales: number }[] = [];
  const now = new Date();
  for (let i = 6; i >= 0; i -= 1) {
    const day = new Date(
      Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - i)
    );
    days.push({ date: day.toISOString().slice(0, 10), revenue: 0, sales: 0 });
  }
  return days;
}

export function DashboardPage() {
  const [groupId, setGroupId] = useState("all");
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    const load = () => {
      fetchDashboard(groupId)
        .then((next) => {
          if (alive) {
            setData(next);
            setError(null);
          }
        })
        .catch((err) => {
          if (alive) setError(err instanceof Error ? err.message : String(err));
        });
    };
    load();
    const poll = window.setInterval(load, 20000);
    return () => {
      alive = false;
      window.clearInterval(poll);
    };
  }, [groupId]);

  const k = data?.kpis;
  const weekly = weekSeries(data?.weekly);
  const maxWeekly = Math.max(1, ...weekly.map((day) => day.revenue));
  const connected = Boolean(data?.user);
  const visibleNotes = data?.notes || [];
  const postable = (data?.groups || []).filter((group) => group.canPost);
  const filterGroups = (data?.groups || []).filter(
    (group) => group.canPost || group.canViewSales
  );

  return (
    <div className="desk dash">
      <div className="desk-top">
        <div>
          <p className="desk-kicker">Studio</p>
          <h1 className="desk-title">Dashboard</h1>
        </div>
        <div className="dash-toolbar">
          <select
            value={groupId}
            onChange={(event) => setGroupId(event.target.value)}
            aria-label="All Groups"
            disabled={!filterGroups.length}
          >
            <option value="all">All groups</option>
            {filterGroups.map((group) => (
              <option key={group.id} value={String(group.id)}>
                {group.canPost
                  ? `${group.name} — ${group.reason || "Can post"}`
                  : `${group.name} — view only`}
              </option>
            ))}
          </select>
          {connected ? (
            <div className="dash-user">
              {data?.user?.avatarUrl ? (
                <img src={data.user.avatarUrl} alt="" className="dash-avatar" />
              ) : null}
              <span>{data?.user?.displayName}</span>
            </div>
          ) : (
            <Link to="/painel/conta" className="btn btn-solid">
              Connect account
            </Link>
          )}
        </div>
      </div>

      {error && <p className="desk-error">{error}</p>}
      {visibleNotes.map((note) => (
        <p key={note} className="desk-note">
          {note}
        </p>
      ))}

      <section className="money">
        <div className="money-hero">
          <p className="money-label">Today revenue</p>
          <p className="money-figure">{robux(k?.todayRevenue || 0)}</p>
          <p className="money-sub">
            <strong>{k?.todaySales ?? 0}</strong> sales today
            <span className="status-sep">·</span>
            {data?.sources.sales === "live" ? "Live transactions" : "Waiting for cookie"}
          </p>
        </div>
        <div className="money-side">
          <div className="money-tile">
            <p className="money-label">Total revenue</p>
            <p className="money-mid">{robux(k?.totalRevenue || 0)}</p>
            <p className="money-hint">
              {data?.totalsExact ? "Year totals" : "Loaded window"}
            </p>
          </div>
          <div className="money-tile">
            <p className="money-label">Total sales</p>
            <p className="money-mid">{k?.totalSales ?? 0}</p>
            <p className="money-hint">
              {data?.totalsExact ? "Year totals" : "Loaded window"}
            </p>
          </div>
        </div>
      </section>

      <ul className="ops-strip">
        <li>
          <em>Uploads</em>
          <strong>{k?.sessionUploads ?? 0}</strong>
        </li>
        <li>
          <em>Failed</em>
          <strong>{k?.failed ?? 0}</strong>
        </li>
        <li>
          <em>Moderated</em>
          <strong>{k?.moderated ?? 0}</strong>
        </li>
        <li>
          <em>Uptime</em>
          <strong>{uptimeLabel(k?.uptimeSeconds || 0)}</strong>
        </li>
        <li>
          <em>Queue</em>
          <strong>
            <Link to="/painel/upload">
              {data?.queue.status || "idle"} · {data?.queue.pending ?? 0} pending
            </Link>
          </strong>
        </li>
      </ul>

      <section className="dash-chart">
        <div className="dash-chart-head">
          <h2 className="desk-h2">Weekly revenue</h2>
          <p className="desk-sub">Last seven days</p>
        </div>
        <div className="week-chart">
          {weekly.map((day) => (
            <div key={day.date} className="week-col">
              <span className="week-val">{day.revenue ? robux(day.revenue) : "—"}</span>
              <div className="week-track">
                <div
                  className="week-bar"
                  style={{
                    height: `${Math.max(10, (day.revenue / maxWeekly) * 100)}%`,
                  }}
                  title={`${day.date}: ${robux(day.revenue)} · ${day.sales} sales`}
                />
              </div>
              <span>{day.date.slice(5)}</span>
            </div>
          ))}
        </div>
      </section>

      <div className="dash-split">
        <section>
          <h2 className="desk-h2">Top keywords</h2>
          {(data?.keywords || []).length === 0 ? (
            <p className="desk-sub">No sales names yet.</p>
          ) : (
            <ul className="dash-list">
              {data!.keywords.map((row) => (
                <li key={row.term}>
                  <span>{row.term}</span>
                  <em>
                    {row.count}
                    {row.robux ? ` · ${robux(row.robux)}` : ""}
                  </em>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section>
          <h2 className="desk-h2">Groups</h2>
          {postable.length === 0 ? (
            <p className="desk-sub">
              {data?.connected
                ? "No groups you can post to"
                : "Connect an account to list groups."}
            </p>
          ) : null}
          {(data?.groups || []).length > 0 ? (
            <ul className="dash-list">
              {data!.groups.map((group) => (
                <li key={group.id}>
                  <span>{group.name}</span>
                  <em>
                    {group.role}
                    {group.canPost
                      ? ` · ${group.reason || "Can post"}`
                      : " · view only"}
                  </em>
                </li>
              ))}
            </ul>
          ) : null}
        </section>
      </div>
    </div>
  );
}
