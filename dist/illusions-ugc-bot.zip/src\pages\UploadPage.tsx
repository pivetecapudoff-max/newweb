import { FormEvent, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  deleteUpload,
  fetchUploads,
  queueUpload,
  retryUpload,
  uploadFileHref,
  type ClothingKind,
  type UploadBoard,
  type UploadJob,
} from "../lib/api";

const KINDS: { id: ClothingKind; label: string; hint: string }[] = [
  { id: "shirt", label: "Shirt", hint: "Classic shirt template · 585×559" },
  { id: "pants", label: "Pants", hint: "Classic pants template · 585×559" },
  { id: "tshirt", label: "T-shirt", hint: "Square image on a tee" },
];

function readFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.onload = () => resolve(String(reader.result || ""));
    reader.readAsDataURL(file);
  });
}

function statusLabel(status: UploadJob["status"]): string {
  if (status === "queued") return "Queued";
  if (status === "uploading") return "Posting";
  if (status === "live") return "Live";
  if (status === "moderated") return "Moderated";
  return "Failed";
}

export function UploadPage() {
  const [board, setBoard] = useState<UploadBoard | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [kind, setKind] = useState<ClothingKind>("shirt");
  const [price, setPrice] = useState(5);
  const [groupId, setGroupId] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () => {
    fetchUploads()
      .then(setBoard)
      .catch((err) => setError(err instanceof Error ? err.message : String(err)));
  };

  useEffect(() => {
    load();
    const poll = window.setInterval(load, 4000);
    return () => window.clearInterval(poll);
  }, []);

  async function onFile(next: File | null) {
    setFile(next);
    setPreview(null);
    if (!next) return;
    setPreview(await readFile(next));
    if (!name.trim()) setName(next.name.replace(/\.[^.]+$/, "").slice(0, 50));
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!file || !preview) {
      setError("Drop a PNG or JPEG template first.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await queueUpload({
        name,
        description,
        kind,
        price,
        groupId: groupId ? Number(groupId) : null,
        fileName: file.name,
        image: preview,
      });
      setFile(null);
      setPreview(null);
      setName("");
      setDescription("");
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="desk upload-desk">
      <div className="desk-top">
        <div>
          <p className="desk-kicker">Publish</p>
          <h1 className="desk-title">Upload</h1>
          <p className="desk-sub">
            Illusions posts the file to <em>your</em> Roblox account. Classic shirts,
            pants, and t-shirts. 3D layered UGC still goes through Creator Dashboard.
          </p>
        </div>
      </div>

      {!board?.connected && (
        <p className="desk-note">
          Connect your cookie on <Link to="/painel/conta">Account</Link> first.
        </p>
      )}

      <form onSubmit={onSubmit} className="upload-grid">
        <label className="upload-drop">
          <input
            type="file"
            accept="image/png,image/jpeg"
            hidden
            onChange={(event) => onFile(event.target.files?.[0] || null)}
          />
          {preview ? (
            <img src={preview} alt="" className="upload-preview" />
          ) : (
            <span>Drop a shirt / pants template</span>
          )}
        </label>

        <div className="upload-fields">
          <div className="cluster-keys">
            {KINDS.map((row) => (
              <button
                key={row.id}
                type="button"
                className={`kw${kind === row.id ? " is-on" : ""}`}
                onClick={() => setKind(row.id)}
              >
                {row.label}
              </button>
            ))}
          </div>
          <p className="desk-sub">{KINDS.find((row) => row.id === kind)?.hint}</p>

          <label className="desk-field">
            <span>Name</span>
            <input value={name} onChange={(event) => setName(event.target.value)} required />
          </label>
          <label className="desk-field">
            <span>Description</span>
            <input
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              placeholder="Optional"
            />
          </label>
          <label className="desk-field">
            <span>Price (R$)</span>
            <input
              type="number"
              min={kind === "tshirt" ? 0 : 5}
              value={price}
              onChange={(event) => setPrice(Number(event.target.value))}
            />
          </label>
          <label className="desk-field">
            <span>Post as</span>
            <select value={groupId} onChange={(event) => setGroupId(event.target.value)}>
              <option value="">My account</option>
              {(board?.groups || []).map((group) => (
                <option key={group.id} value={String(group.id)}>
                  {group.name} — {group.reason || group.role}
                </option>
              ))}
            </select>
            {(board?.connected && (board.groups || []).length === 0) ? (
              <p className="desk-sub">No groups you can post to</p>
            ) : null}
          </label>
          <button type="submit" className="btn btn-solid" disabled={busy || !board?.connected}>
            {busy ? "Queuing…" : "Post now"}
          </button>
        </div>
      </form>

      {error && <p className="desk-error">{error}</p>}

      <section className="desk-section">
        <h2 className="desk-h2">Queue</h2>
        {(board?.jobs || []).length === 0 ? (
          <p className="desk-sub">Nothing in the queue.</p>
        ) : (
          <ul className="dash-list">
            {(board?.jobs || []).map((job) => (
              <li key={job.id} className="upload-row">
                <span>
                  <strong>{job.name}</strong>
                  <em>
                    {" "}
                    · {job.kind} · {statusLabel(job.status)}
                    {job.assetId ? ` · ${job.assetId}` : ""}
                  </em>
                  {job.error ? <em className="upload-err"> · {job.error}</em> : null}
                </span>
                <span className="upload-actions">
                  <a href={uploadFileHref(job.id)} download>
                    Download
                  </a>
                  {job.catalogUrl ? (
                    <a href={job.catalogUrl} target="_blank" rel="noreferrer">
                      Catalog
                    </a>
                  ) : null}
                  {job.status === "failed" || job.status === "moderated" ? (
                    <button type="button" className="shell-signout" onClick={() => retryUpload(job.id).then(load)}>
                      Retry
                    </button>
                  ) : null}
                  <button type="button" className="shell-signout" onClick={() => deleteUpload(job.id).then(load)}>
                    Remove
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
