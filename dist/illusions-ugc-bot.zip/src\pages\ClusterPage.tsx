import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { fetchCluster, itemPreviewHref, type ClusterDetail } from "../lib/api";
import {
  CATEGORY_LABEL,
  VERDICT_LABEL,
  demandCaption,
  demandNoun,
  formatDemand,
} from "../lib/labels";
import { ItemThumb } from "../components/ItemThumb";
import { SignalBadge, VerdictBadge } from "../components/VerdictBadge";

function catalogUrl(item: ClusterDetail["items"][number]): string {
  return item.itemType === "Bundle"
    ? `https://www.roblox.com/bundles/${item.id}`
    : `https://www.roblox.com/catalog/${item.id}`;
}

export function ClusterPage() {
  const { id = "" } = useParams();
  const [data, setData] = useState<ClusterDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchCluster(id)
      .then(setData)
      .catch((err) => setError(err instanceof Error ? err.message : String(err)));
  }, [id]);

  if (error) {
    return (
      <div>
        <Link to="/painel" className="desk-back">
          ← Back to feed
        </Link>
        <p className="desk-error">{error}</p>
      </div>
    );
  }

  if (!data) {
    return <p className="desk-sub">Loading theme…</p>;
  }

  const { cluster, items, history } = data;
  const m = cluster.metrics;

  return (
    <div className="desk">
      <Link to="/painel" className="desk-back">
        ← Back to feed
      </Link>

      <div className="cluster-head cluster-head--page">
        <div>
          <p className="cluster-kicker">{CATEGORY_LABEL[cluster.category]}</p>
          <h1 className="desk-title">{cluster.label}</h1>
        </div>
        <VerdictBadge verdict={cluster.verdict} />
      </div>

      {cluster.badges.length > 0 && (
        <div className="cluster-chips">
          {cluster.badges.map((badge) => (
            <SignalBadge key={badge} badge={badge} />
          ))}
        </div>
      )}

      {cluster.matchedIp && (
        <p className="desk-sub">
          Matched reference: <strong>{cluster.matchedIp}</strong>
          <span> · {data.overlaySource}</span>
        </p>
      )}

      <div className="cluster-metrics cluster-metrics--page">
        <span>
          <strong>{m.demandTotal ?? 0}</strong> {demandNoun(m.demandField).toLowerCase()}
        </span>
        <span>
          <strong>{m.acceleration.toFixed(2)}</strong> accel
        </span>
        <span>
          <strong>{m.uniqueCreators}</strong> creators
        </span>
        <span>
          <strong>{m.size}</strong> size
        </span>
        <span>
          <strong>{m.velocity}</strong> velocity
        </span>
      </div>
      <p className="cluster-note">
        {demandCaption(m.demandField)}. Economy sales: {m.salesTotal ?? 0}
        {m.itemsWithSales ? ` on ${m.itemsWithSales} item(s)` : ""}. Catalog favorites:{" "}
        {m.favoritesTotal ?? 0}.
        {m.topSellerName ? ` Highest demand: ${m.topSellerName} (${m.topSellerDemand}).` : ""}
      </p>

      <section className="desk-section">
        <h2 className="desk-h2">Cluster words</h2>
        <div className="cluster-keys">
          {cluster.keywords.map((row) => (
            <span key={row.term} className="kw">
              {row.term}
              <em>{row.weight.toFixed(2)}</em>
            </span>
          ))}
        </div>
      </section>

      <section className="desk-section">
        <h2 className="desk-h2">Item previews</h2>
        <div className="item-grid">
          {items.map((item) => (
            <article key={`${item.itemType}-${item.id}`} className="item-tile">
              <ItemThumb url={item.thumbnailUrl} name={item.name} className="item-tile-img" />
              <div className="item-tile-meta">
                <p>{item.name}</p>
                <span>
                  {formatDemand(
                    item.demandField === "vendas" ? item.saleCount || 0 : item.favoriteCount || 0,
                    item.demandField
                  )}
                  {item.demandField === "vendas" && item.favoriteCount
                    ? ` · ${item.favoriteCount} fav`
                    : ""}
                </span>
                <span>
                  {item.creatorName}
                  {item.createdAt
                    ? ` · ${new Date(item.createdAt).toLocaleDateString("en-US")}`
                    : ""}
                </span>
                <span className="item-tile-actions">
                  <a href={catalogUrl(item)} target="_blank" rel="noreferrer">
                    Catalog
                  </a>
                  {item.thumbnailUrl ? (
                    <a href={itemPreviewHref(item.id)} download>
                      Download preview
                    </a>
                  ) : null}
                </span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="desk-section">
        <h2 className="desk-h2">Cycle history</h2>
        {history.length < 2 && (
          <p className="cluster-note">
            Acceleration is honest after the second scan. Run again to compare velocity.
          </p>
        )}
        <div className="desk-table-wrap">
          <table className="desk-table">
            <thead>
              <tr>
                <th>When</th>
                <th>Verdict</th>
                <th>Size</th>
                <th>Vel.</th>
                <th>Accel.</th>
                <th>Purity</th>
                <th>Demand</th>
              </tr>
            </thead>
            <tbody>
              {history.map((row) => (
                <tr key={row.cycleId}>
                  <td>{new Date(row.finishedAt).toLocaleString("en-US")}</td>
                  <td>{VERDICT_LABEL[row.verdict]}</td>
                  <td>{row.metrics.size}</td>
                  <td>{row.metrics.velocity}</td>
                  <td>{row.metrics.acceleration.toFixed(2)}</td>
                  <td>{row.metrics.purity.toFixed(2)}</td>
                  <td>{row.metrics.demandTotal ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
