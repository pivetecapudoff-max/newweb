import { BADGE_LABEL, VERDICT_LABEL, type Badge, type Verdict } from "../lib/labels";

export function VerdictBadge({ verdict }: { verdict: Verdict }) {
  return <span className={`chip chip--${verdict}`}>{VERDICT_LABEL[verdict]}</span>;
}

export function SignalBadge({ badge }: { badge: Badge }) {
  return <span className="chip">{BADGE_LABEL[badge]}</span>;
}
