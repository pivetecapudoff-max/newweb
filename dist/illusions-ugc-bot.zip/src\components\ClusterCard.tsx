import { Link } from "react-router-dom";
import type { Cluster } from "../lib/api";
import { CATEGORY_LABEL, demandNoun, formatDemand } from "../lib/labels";
import { ItemThumb } from "./ItemThumb";
import { SignalBadge, VerdictBadge } from "./VerdictBadge";

export function ClusterCard({ cluster }: { cluster: Cluster }) {
  const demandLabel = demandNoun(cluster.metrics.demandField);
  const previews = cluster.previews || [];

  return (
    <Link to={`/painel/tema/${cluster.id}`} className="cluster">
      {previews.length > 0 && (
        <div className="cluster-thumbs">
          {previews.slice(0, 4).map((preview) => (
            <div key={`${preview.itemType}-${preview.id}`} className="cluster-thumb">
              <ItemThumb
                url={preview.thumbnailUrl}
                name={preview.name}
                className="cluster-thumb-img"
              />
            </div>
          ))}
        </div>
      )}

      <div className="cluster-head">
        <div>
          <p className="cluster-kicker">
            {CATEGORY_LABEL[cluster.category]}
            {cluster.flagged ? " · alert" : ""}
          </p>
          <h3 className="cluster-title">{cluster.label}</h3>
        </div>
        <VerdictBadge verdict={cluster.verdict} />
      </div>

      {cluster.badges.length > 0 && (
        <div className="cluster-chips">
          {cluster.badges.map((badge) => (
            <SignalBadge key={badge} badge={badge} />
          ))}
        </div>
      )}

      <div className="cluster-metrics">
        <span>
          <strong>{cluster.metrics.demandTotal ?? 0}</strong> {demandLabel.toLowerCase()}
        </span>
        <span>
          <strong>{cluster.metrics.acceleration.toFixed(2)}</strong> accel
        </span>
        <span>
          <strong>{cluster.metrics.uniqueCreators}</strong> creators
        </span>
      </div>

      {previews[0] && (
        <p className="cluster-note">
          Top {formatDemand(
            previews[0].demandField === "vendas"
              ? previews[0].saleCount || 0
              : previews[0].favoriteCount || 0,
            previews[0].demandField
          )}
          {cluster.metrics.topSellerName ? ` · ${cluster.metrics.topSellerName}` : ""}
        </p>
      )}

      <div className="cluster-keys">
        {cluster.keywords.slice(0, 5).map((row) => (
          <span key={row.term} className="kw">
            {row.term}
          </span>
        ))}
      </div>
    </Link>
  );
}
