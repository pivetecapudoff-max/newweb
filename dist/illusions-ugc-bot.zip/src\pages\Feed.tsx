import { FormEvent, useEffect, useMemo, useState } from "react";
import { Download, LoaderCircle, Radar } from "lucide-react";
import { ClusterCard } from "../components/ClusterCard";
import {
  exportHref,
  fetchFeed,
  startScan,
  type FeedQuery,
  type FeedResponse,
} from "../lib/api";
import { BADGE_LABEL, CATEGORY_LABEL, VERDICT_LABEL } from "../lib/labels";

const emptyQuery: FeedQuery = {
  q: "",
  verdict: "",
  category: "",
  badge: "",
  sort: "oportunidade",
  flagged: false,
  isolados: false,
  minSales: "",
  maxSales: "",
  minFavorites: "",
};

const SALES_MIN = [
  ["", "Min sales"],
  ["1", "Sold 1+"],
  ["10", "Sold 10+"],
  ["50", "Sold 50+"],
  ["100", "Sold 100+"],
  ["500", "Sold 500+"],
] as const;

const SALES_MAX = [
  ["", "Max sales"],
  ["10", "Sold ≤10"],
  ["50", "Sold ≤50"],
  ["100", "Sold ≤100"],
  ["500", "Sold ≤500"],
] as const;

const FAV_MIN = [
  ["", "Min favorites"],
  ["10", "Fav 10+"],
  ["50", "Fav 50+"],
  ["100", "Fav 100+"],
  ["500", "Fav 500+"],
] as const;

function formatWhen(value: string | null): string {
  if (!value) return "—";
  return new Date(value).toLocaleString("en-US");
}

export function Feed() {
  const [query, setQuery] = useState<FeedQuery>(emptyQuery);
  const [draft, setDraft] = useState("");
  const [data, setData] = useState<FeedResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [now, setNow] = useState(Date.now());

  const load = async (next = query) => {
    setError(null);
    try {
      setData(await fetchFeed(next));
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  };

  useEffect(() => {
    load();
    const poll = window.setInterval(() => load(query), 7000);
    const tick = window.setInterval(() => setNow(Date.now()), 1000);
    return () => {
      window.clearInterval(poll);
      window.clearInterval(tick);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  useEffect(() => {
    const handle = window.setTimeout(() => {
      if (draft === (query.q || "")) return;
      const next = { ...query, q: draft };
      setQuery(next);
    }, 280);
    return () => window.clearTimeout(handle);
  }, [draft, query]);

  async function scan() {
    setScanning(true);
    setError(null);
    try {
      await startScan();
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setScanning(false);
    }
  }

  function applyFilters(event: FormEvent) {
    event.preventDefault();
    const next = { ...query, q: draft };
    setQuery(next);
    load(next);
  }

  function patch(partial: Partial<FeedQuery>) {
    const next = { ...query, ...partial };
    setQuery(next);
    load(next);
  }

  const clusters = data?.cycle?.clusters || [];
  const mock = data?.cycle?.source === "mock";
  const csv = useMemo(() => exportHref(query), [query]);
  const nextMs = data?.health.nextRunAt
    ? new Date(data.health.nextRunAt).getTime() - now
    : null;
  const nextLabel =
    data?.health.scanning
      ? "scanning now"
      : nextMs == null
        ? data?.settings.autoScan
          ? "any moment"
          : "paused"
        : nextMs <= 0
          ? "any moment"
          : `${Math.floor(nextMs / 60000)}m ${Math.floor((nextMs % 60000) / 1000)
              .toString()
              .padStart(2, "0")}s`;

  const healthLine = data?.health.scanning
    ? "Reading the public catalog…"
    : data?.health.lastError
      ? "Public read failed; local sample marked"
      : data?.cycle
        ? `${data.health.lastItemCount || data.cycle.itemCount} items · ${data.health.lastSource || "—"}`
        : "First cycle incoming";

  return (
    <div className="desk">
      <div className="desk-top">
        <div>
          <p className="desk-kicker">Catalog</p>
          <h1 className="desk-title">Today’s themes</h1>
          <p className="desk-sub">Clustered titles from the public catalog</p>
        </div>
        <div className="desk-actions">
          <a href={csv} className="btn btn-ghost" title="Export CSV">
            <Download size={16} />
            CSV
          </a>
          <button
            type="button"
            onClick={scan}
            disabled={scanning || data?.health.scanning}
            className="btn btn-solid"
            title="Scan now"
          >
            {scanning || data?.health.scanning ? (
              <LoaderCircle size={16} className="animate-spin" />
            ) : (
              <Radar size={16} />
            )}
            Scan now
          </button>
        </div>
      </div>

      <div className="status-bar">
        <span
          className={`status-dot${
            data?.health.scanning ? " is-live" : data?.settings.autoScan ? " is-on" : ""
          }`}
        />
        <p>
          {data?.health.scanning
            ? "Scanning the catalog"
            : data?.settings.autoScan
              ? `Live scan on · next in ${nextLabel}`
              : "Live scan paused"}
          <span className="status-sep">·</span>
          {healthLine}
          {data?.demand ? (
            <>
              <span className="status-sep">·</span>
              {data.demand.salesTotal} sales · {data.demand.favoritesTotal} favorites
            </>
          ) : null}
          <span className="status-sep">·</span>
          Last {formatWhen(data?.health.lastSuccessAt || null)}
        </p>
      </div>

      {data?.cycle?.note && <p className="desk-note">{data.cycle.note}</p>}

      <form onSubmit={applyFilters} className="filter-row">
        <input
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder="Search viral themes…"
          className="filter-search"
          aria-label="Search viral themes"
        />
        <button type="submit" className="btn btn-ghost filter-go">
          Search
        </button>
        <select
          value={query.minSales === "" || query.minSales == null ? "" : String(query.minSales)}
          onChange={(event) =>
            patch({ minSales: event.target.value === "" ? "" : Number(event.target.value) })
          }
          aria-label="Min sales"
        >
          {SALES_MIN.map(([value, label]) => (
            <option key={value || "any"} value={value}>
              {label}
            </option>
          ))}
        </select>
        <select
          value={query.maxSales === "" || query.maxSales == null ? "" : String(query.maxSales)}
          onChange={(event) =>
            patch({ maxSales: event.target.value === "" ? "" : Number(event.target.value) })
          }
          aria-label="Max sales"
        >
          {SALES_MAX.map(([value, label]) => (
            <option key={value || "any"} value={value}>
              {label}
            </option>
          ))}
        </select>
        <select
          value={
            query.minFavorites === "" || query.minFavorites == null
              ? ""
              : String(query.minFavorites)
          }
          onChange={(event) =>
            patch({
              minFavorites: event.target.value === "" ? "" : Number(event.target.value),
            })
          }
          aria-label="Min favorites"
        >
          {FAV_MIN.map(([value, label]) => (
            <option key={value || "any-fav"} value={value}>
              {label}
            </option>
          ))}
        </select>
        <select
          value={query.verdict}
          onChange={(event) => patch({ verdict: event.target.value })}
          aria-label="Verdict"
        >
          <option value="">All verdicts</option>
          {Object.entries(VERDICT_LABEL).map(([key, label]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </select>
        <select
          value={query.category}
          onChange={(event) => patch({ category: event.target.value })}
          aria-label="Category"
        >
          <option value="">All categories</option>
          {Object.entries(CATEGORY_LABEL).map(([key, label]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </select>
        <select
          value={query.sort}
          onChange={(event) => patch({ sort: event.target.value })}
          aria-label="Sort"
        >
          <option value="oportunidade">Sort: opportunity</option>
          <option value="tamanho">Sort: size</option>
          <option value="velocidade">Sort: velocity</option>
          <option value="aceleracao">Sort: acceleration</option>
          <option value="pureza">Sort: purity</option>
          <option value="criadores">Sort: creators</option>
          <option value="vendas">Sort: sales</option>
        </select>
        <label className="filter-check">
          <input
            type="checkbox"
            checked={Boolean(query.flagged)}
            onChange={(event) => patch({ flagged: event.target.checked })}
          />
          Alerts only
        </label>
        <label className="filter-check">
          <input
            type="checkbox"
            checked={Boolean(query.isolados)}
            onChange={(event) => patch({ isolados: event.target.checked })}
          />
          Include isolates
        </label>
      </form>

      <div className="filter-chips">
        {Object.entries(BADGE_LABEL).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => patch({ badge: query.badge === key ? "" : key })}
            className={`kw${query.badge === key ? " is-on" : ""}`}
          >
            {label}
          </button>
        ))}
      </div>

      {error && <p className="desk-error">{error}</p>}

      {!data?.cycle && !error && (
        <div className="desk-empty">
          <p>No cycle yet</p>
          <span>The server already scans on its own. The first cycle shows up in a few seconds.</span>
        </div>
      )}

      {mock && (
        <p className="desk-note">These cards are a local sample. Do not mix them with a live read.</p>
      )}

      {data?.cycle && clusters.length === 0 && !error && (
        <div className="desk-empty">
          <p>Nothing matches</p>
          <span>Try a looser sales floor or a shorter viral search.</span>
        </div>
      )}

      <div className="cluster-grid">
        {clusters.map((cluster) => (
          <ClusterCard key={cluster.id} cluster={cluster} />
        ))}
      </div>
    </div>
  );
}
