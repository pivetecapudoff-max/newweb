import { mkdirSync, readFileSync, unlinkSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const dataDir = path.join(rootDir, "data");
const accountPath = path.join(dataDir, "account.json");

export interface StoredOps {
  sessionUploads: number;
  failed: number;
  moderated: number;
}

interface StoredAccount {
  cookie: string;
  userId: number;
  username: string;
  displayName: string | null;
  connectedAt: string;
  ops: StoredOps;
}

const EMPTY_OPS: StoredOps = {
  sessionUploads: 0,
  failed: 0,
  moderated: 0,
};

export function sanitizeCookie(raw: string): string {
  let value = String(raw || "").trim();
  value = value.replace(/^Cookie:\s*/i, "");
  const embedded = value.match(/\.ROBLOSECURITY\s*=\s*([^;]+)/i);
  if (embedded) value = embedded[1];
  value = value.replace(/^\.ROBLOSECURITY\s*=\s*/i, "").trim();
  return value;
}

export function loadAccount(): StoredAccount | null {
  try {
    const raw = JSON.parse(readFileSync(accountPath, "utf8")) as StoredAccount;
    if (!raw?.cookie || !raw.userId) return null;
    return {
      ...raw,
      ops: { ...EMPTY_OPS, ...(raw.ops || {}) },
    };
  } catch {
    return null;
  }
}

export function saveAccount(account: StoredAccount): void {
  mkdirSync(dataDir, { recursive: true });
  writeFileSync(accountPath, JSON.stringify(account, null, 2), "utf8");
}

export function clearAccount(): void {
  try {
    unlinkSync(accountPath);
  } catch {
    // already gone
  }
}

export function publicAccount() {
  const account = loadAccount();
  if (!account) {
    return {
      connected: false,
      userId: null,
      username: null,
      displayName: null,
      connectedAt: null,
      ops: { ...EMPTY_OPS },
    };
  }
  return {
    connected: true,
    userId: account.userId,
    username: account.username,
    displayName: account.displayName,
    connectedAt: account.connectedAt,
    ops: account.ops,
  };
}

export function cookieOf(): string | null {
  return loadAccount()?.cookie || null;
}

export function bumpOps(delta: Partial<StoredOps>): StoredOps {
  const account = loadAccount();
  if (!account) return { ...EMPTY_OPS };
  account.ops = {
    sessionUploads: account.ops.sessionUploads + (delta.sessionUploads || 0),
    failed: account.ops.failed + (delta.failed || 0),
    moderated: account.ops.moderated + (delta.moderated || 0),
  };
  saveAccount(account);
  return account.ops;
}
