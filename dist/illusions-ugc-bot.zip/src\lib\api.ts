import type { Badge, Category, Verdict } from "./labels";

export interface ClusterKeyword {
  term: string;
  weight: number;
}

export interface ClusterMetrics {
  size: number;
  uniqueCreators: number;
  velocity: number;
  velocityPerHour: number;
  previousVelocity: number | null;
  acceleration: number;
  purity: number;
  salesTotal: number;
  salesAvg: number;
  favoritesTotal: number;
  demandTotal: number;
  demandAvg: number;
  demandVelocity: number;
  previousDemandTotal: number | null;
  demandAcceleration: number;
  demandField: "vendas" | "favoritos";
  itemsWithSales: number;
  topSellerName: string | null;
  topSellerDemand: number;
}

export interface Cluster {
  id: string;
  label: string;
  keywords: ClusterKeyword[];
  category: Category;
  verdict: Verdict;
  badges: Badge[];
  metrics: ClusterMetrics;
  itemIds: number[];
  sampleTitles: string[];
  previews: {
    id: number;
    name: string;
    itemType: string;
    thumbnailUrl: string | null;
    saleCount: number | null;
    favoriteCount: number;
    demandField: "vendas" | "favoritos";
  }[];
  matchedIp: string | null;
  flagged: boolean;
}

export interface Health {
  scanning: boolean;
  lastRunAt: string | null;
  lastSuccessAt: string | null;
  nextRunAt: string | null;
  lastError: string | null;
  lastItemCount: number;
  lastSource: "live" | "mock" | null;
  lastDurationMs: number | null;
  lastReason: "manual" | "auto" | null;
}

export interface Settings {
  autoScan: boolean;
  intervalMinutes: number;
  categories: Category[];
  pagesPerCategory: number;
  alertMinVelocity: number;
  alertMinAcceleration: number;
  alertMinPurity: number;
  discordWebhook: string;
  discordWebhookSet?: boolean;
}

export interface FeedResponse {
  health: Health;
  settings: Settings;
  overlaySource: string;
  demand: {
    salesTotal: number;
    favoritesTotal: number;
    field: "vendas" | "favoritos";
    label: string;
  } | null;
  cycle: {
    id: string;
    finishedAt: string;
    source: "live" | "mock";
    itemCount: number;
    hoursSincePrevious: number | null;
    note: string | null;
    clusters: Cluster[];
  } | null;
}

export interface CatalogItem {
  id: number;
  itemType: string;
  name: string;
  creatorName: string;
  createdAt: string | null;
  favoriteCount: number;
  price: number | null;
  category: Category;
  thumbnailUrl?: string | null;
  saleCount?: number | null;
  demandField?: "vendas" | "favoritos";
}

export interface ClusterDetail {
  cluster: Cluster;
  items: CatalogItem[];
  history: {
    cycleId: string;
    finishedAt: string;
    source: "live" | "mock";
    metrics: ClusterMetrics;
    verdict: Verdict;
  }[];
  overlaySource: string;
}

export interface FeedQuery {
  q?: string;
  verdict?: string;
  category?: string;
  badge?: string;
  sort?: string;
  flagged?: boolean;
  isolados?: boolean;
  minSales?: number | "";
  maxSales?: number | "";
  minFavorites?: number | "";
}

function qs(query: FeedQuery = {}): string {
  const params = new URLSearchParams();
  if (query.q) params.set("q", query.q);
  if (query.verdict) params.set("verdict", query.verdict);
  if (query.category) params.set("category", query.category);
  if (query.badge) params.set("badge", query.badge);
  if (query.sort) params.set("sort", query.sort);
  if (query.flagged) params.set("flagged", "1");
  if (query.minSales !== "" && query.minSales != null) {
    params.set("minSales", String(query.minSales));
  }
  if (query.maxSales !== "" && query.maxSales != null) {
    params.set("maxSales", String(query.maxSales));
  }
  if (query.minFavorites !== "" && query.minFavorites != null) {
    params.set("minFavorites", String(query.minFavorites));
  }
  params.set("minSize", query.isolados ? "1" : "2");
  const text = params.toString();
  return text ? `?${text}` : "";
}

async function readJson<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(body.error || res.statusText);
  }
  return res.json() as Promise<T>;
}

export function fetchFeed(query: FeedQuery = {}): Promise<FeedResponse> {
  return fetch(`/api/feed${qs(query)}`).then((res) => readJson<FeedResponse>(res));
}

export function fetchCluster(id: string): Promise<ClusterDetail> {
  return fetch(`/api/clusters/${encodeURIComponent(id)}`).then((res) =>
    readJson<ClusterDetail>(res)
  );
}

export function startScan(): Promise<{ source: string; itemCount: number; note: string | null }> {
  return fetch("/api/scan", { method: "POST" }).then((res) =>
    readJson<{ source: string; itemCount: number; note: string | null }>(res)
  );
}

export function fetchSettings(): Promise<Settings> {
  return fetch("/api/settings").then((res) => readJson<Settings>(res));
}

export function saveSettings(patch: Partial<Settings>): Promise<Settings> {
  return fetch("/api/settings", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch),
  }).then((res) => readJson<Settings>(res));
}

export function exportHref(query: FeedQuery = {}): string {
  return `/api/export.csv${qs(query)}`;
}

export function itemPreviewHref(id: number): string {
  return `/api/items/${id}/preview`;
}

export function uploadFileHref(id: string): string {
  return `/api/uploads/${id}/file`;
}

export interface AccountPublic {
  connected: boolean;
  userId: number | null;
  username: string | null;
  displayName: string | null;
  connectedAt: string | null;
  ops: {
    sessionUploads: number;
    failed: number;
    moderated: number;
  };
}

export interface DashboardData {
  connected: boolean;
  user: {
    id: number;
    name: string;
    displayName: string;
    avatarUrl: string | null;
  } | null;
  groupId: number | "all";
  groups: {
    id: number;
    name: string;
    role: string;
    rank: number;
    canPost?: boolean;
    canViewSales?: boolean;
    reason?: "Owner" | "Create items" | null;
  }[];
  kpis: {
    todayRevenue: number;
    todaySales: number;
    totalRevenue: number;
    totalSales: number;
    sessionUploads: number;
    failed: number;
    moderated: number;
    uptimeSeconds: number;
  };
  totalsExact: boolean;
  queue: {
    pending: number;
    processing: number;
    status: "idle" | "processing";
    note: string;
  };
  weekly: { date: string; revenue: number; sales: number }[];
  keywords: { term: string; count: number; robux: number }[];
  notes: string[];
  sources: {
    user: "live" | "none" | "error";
    sales: "live" | "empty" | "forbidden" | "none";
    groups: "live" | "empty" | "forbidden" | "none";
  };
}

export function fetchAccount(): Promise<AccountPublic> {
  return fetch("/api/account").then((res) => readJson<AccountPublic>(res));
}

export function connectAccount(cookie: string): Promise<AccountPublic> {
  return fetch("/api/account", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cookie }),
  }).then((res) => readJson<AccountPublic>(res));
}

export function disconnectAccount(): Promise<AccountPublic> {
  return fetch("/api/account", { method: "DELETE" }).then((res) =>
    readJson<AccountPublic>(res)
  );
}

export function fetchDashboard(groupId?: string): Promise<DashboardData> {
  const q = groupId && groupId !== "all" ? `?groupId=${encodeURIComponent(groupId)}` : "";
  return fetch(`/api/dashboard${q}`).then((res) => readJson<DashboardData>(res));
}

export type ClothingKind = "shirt" | "pants" | "tshirt";
export type UploadStatus = "queued" | "uploading" | "live" | "failed" | "moderated";

export interface UploadJob {
  id: string;
  name: string;
  description: string;
  kind: ClothingKind;
  price: number;
  groupId: number | null;
  fileName: string;
  mime: string;
  status: UploadStatus;
  assetId: number | null;
  catalogUrl: string | null;
  error: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface UploadGroup {
  id: number;
  name: string;
  role: string;
  rank: number;
  canPost?: boolean;
  reason?: "Owner" | "Create items" | null;
}

export interface UploadBoard {
  connected: boolean;
  jobs: UploadJob[];
  groups: UploadGroup[];
}

export function fetchUploads(): Promise<UploadBoard> {
  return fetch("/api/uploads").then((res) => readJson<UploadBoard>(res));
}

export function queueUpload(body: {
  name: string;
  description?: string;
  kind: ClothingKind;
  price: number;
  groupId: number | null;
  fileName: string;
  image: string;
}): Promise<UploadJob> {
  return fetch("/api/uploads", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).then((res) => readJson<UploadJob>(res));
}

export function retryUpload(id: string): Promise<UploadJob> {
  return fetch(`/api/uploads/${id}/retry`, { method: "POST" }).then((res) =>
    readJson<UploadJob>(res)
  );
}

export function deleteUpload(id: string): Promise<void> {
  return fetch(`/api/uploads/${id}`, { method: "DELETE" }).then((res) => {
    if (!res.ok) throw new Error("Could not remove that upload.");
  });
}
