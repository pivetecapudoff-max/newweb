import { CSSProperties, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Atmosphere } from "../components/Atmosphere";
import { BrandMark, Wordmark } from "../components/Logo";
import { bindAppear } from "../lib/appear";
import { readSession, writeSession } from "../lib/session";

function delay(value: string): CSSProperties {
  return { ["--d" as string]: value };
}

function ensureSession() {
  if (!readSession()) writeSession("creator");
}

export function Landing() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  function closeMenu() {
    setMenuOpen(false);
  }

  function enter(path = "/painel/dashboard") {
    ensureSession();
    closeMenu();
    navigate(path);
  }

  useEffect(() => {
    document.documentElement.classList.add("landing-lock");
    document.body.classList.add("landing-lock");
    document.body.style.background = "#000";
    document.body.style.color = "#fff";
    const release = bindAppear(document);
    return () => {
      release();
      document.documentElement.classList.remove("landing-lock");
      document.body.classList.remove("landing-lock", "menu-open");
    };
  }, []);

  useEffect(() => {
    document.body.classList.toggle("menu-open", menuOpen);
  }, [menuOpen]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeMenu();
    };
    const mq = window.matchMedia("(min-width: 901px)");
    const onBreak = (event: MediaQueryListEvent) => {
      if (event.matches) closeMenu();
    };
    window.addEventListener("keydown", onKey);
    mq.addEventListener("change", onBreak);
    return () => {
      window.removeEventListener("keydown", onKey);
      mq.removeEventListener("change", onBreak);
    };
  }, []);

  return (
    <>
      <Atmosphere />
      <div className="page">
        <div className="menu-backdrop" onClick={closeMenu} />
        <header className="header">
          <a className="logo appear appear--scale" href="#top" aria-label="Illusions UGC Bot" style={delay("0.08s")}>
            <BrandMark />
            <Wordmark />
          </a>

          <nav id="site-nav" aria-label="Primary">
            <a className="nav-pill is-active appear appear--scale" style={delay("0.16s")} href="#top" onClick={closeMenu}>
              Home
            </a>
            <Link
              className="nav-pill appear appear--soft"
              style={delay("0.28s")}
              to="/painel/dashboard"
              onClick={() => {
                ensureSession();
                closeMenu();
              }}
            >
              Desk
            </Link>
            <Link
              className="nav-pill appear appear--scale"
              style={delay("0.40s")}
              to="/painel"
              onClick={() => {
                ensureSession();
                closeMenu();
              }}
            >
              Feed
            </Link>
            <Link
              className="nav-pill appear appear--soft"
              style={delay("0.52s")}
              to="/painel/ajustes"
              onClick={() => {
                ensureSession();
                closeMenu();
              }}
            >
              Settings
            </Link>
          </nav>

          <button
            type="button"
            className="btn btn-solid header-cta appear appear--scale"
            style={delay("0.34s")}
            onClick={() => enter("/painel/dashboard")}
          >
            Open the desk
          </button>

          <button
            type="button"
            className="burger appear appear--scale"
            style={delay("0.34s")}
            aria-controls="site-nav"
            aria-expanded={menuOpen}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            onClick={() => setMenuOpen((open) => !open)}
          >
            <span className="burger-bar" />
            <span className="burger-bar" />
            <span className="burger-bar" />
          </button>
        </header>

        <main className="hero" id="top">
          <div className="hero-copy">
            <h1>
              <span className="headline-line">
                <span className="appear appear--mask" style={delay("0.42s")}>
                  See the <em>themes</em> the
                </span>
              </span>
              <span className="headline-line">
                <span className="appear appear--mask" style={delay("0.62s")}>
                  catalog is repeating.
                </span>
              </span>
            </h1>

            <p className="lede appear appear--soft" style={delay("0.82s")}>
              Illusions UGC Bot reads the public Roblox catalog, clusters similar
              titles, and scores size, creators, velocity, and acceleration.
            </p>

            <div className="hero-actions">
              <button
                type="button"
                className="btn btn-solid appear appear--btn"
                style={delay("0.96s")}
                onClick={() => enter("/painel/dashboard")}
              >
                Open the desk
              </button>
              <a
                className="btn btn-ghost appear appear--side"
                style={delay("1.10s")}
                href="/illusions-ugc-bot.zip"
                download="illusions-ugc-bot.zip"
              >
                Download
              </a>
            </div>
          </div>
        </main>

        <footer className="stats">
          <div className="stat appear appear--stat" style={delay("1.12s")}>
            <svg className="stat-icon" viewBox="0 0 24 24" aria-hidden="true">
              <defs>
                <linearGradient id="ill-pill-a" x1="3" y1="2" x2="14" y2="22">
                  <stop offset="0" stopColor="#ffffff" stopOpacity="0.38" />
                  <stop offset="1" stopColor="#3a3a3a" stopOpacity="0.62" />
                </linearGradient>
                <linearGradient id="ill-pill-b" x1="3" y1="2" x2="14" y2="22">
                  <stop offset="0" stopColor="#3a3a3a" stopOpacity="0.38" />
                  <stop offset="1" stopColor="#ffffff" stopOpacity="0.62" />
                </linearGradient>
              </defs>
              <rect x="3.4" y="2.6" width="7.2" height="18.8" rx="3.6" fill="url(#ill-pill-a)" />
              <rect x="13.4" y="2.6" width="7.2" height="18.8" rx="3.6" fill="url(#ill-pill-b)" />
              <rect x="9.2" y="10.9" width="5.6" height="2.2" rx="1.1" fill="#4a4a4a" />
            </svg>
            Titles clustered into themes
          </div>

          <div className="stat appear appear--stat" style={delay("1.28s")}>
            <svg className="stat-icon" viewBox="0 0 24 24" aria-hidden="true">
              <rect x="2.4" y="2.4" width="19.2" height="19.2" rx="6.2" fill="#ffffff" />
              <path
                d="M12 7.1v7.4M8.15 12.35L12 16.2l3.85-3.85"
                fill="none"
                stroke="#111"
                strokeWidth="1.85"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            Velocity and acceleration on each card
          </div>

          <div className="stat appear appear--stat" style={delay("1.44s")}>
            <svg className="stat-icon-wide" viewBox="0 0 40 22" aria-hidden="true">
              <circle cx="10.2" cy="11" r="9.2" fill="#2b2b2b" />
              <ellipse cx="10.2" cy="12.1" rx="4.15" ry="3.7" fill="#f4f4f4" />
              <path d="M6.6 9.1l-1.7-1.6 2.2.4zM13.8 9.1l1.7-1.6-2.2.4z" fill="#f4f4f4" />
              <circle cx="8.8" cy="11.6" r="0.7" fill="#1a1a1a" />
              <circle cx="11.6" cy="11.6" r="0.7" fill="#1a1a1a" />
              <circle cx="20.2" cy="11" r="9.2" fill="#ffffff" />
              <circle cx="18.2" cy="9.8" r="1.7" fill="#1a1a1a" />
              <circle cx="22.2" cy="9.8" r="1.7" fill="#1a1a1a" />
              <ellipse cx="20.2" cy="12.2" rx="1.1" ry="0.7" fill="#1a1a1a" />
              <path
                d="M17.6 14.4c.8 1.2 2.2 1.9 3.6 1.9s2.8-.7 3.6-1.9"
                fill="none"
                stroke="#111"
                strokeWidth="1.2"
                strokeLinecap="round"
              />
              <circle cx="30.2" cy="11" r="9.2" fill="#f26b1d" />
              <text
                x="30.2"
                y="15.1"
                textAnchor="middle"
                fill="#fff"
                fontFamily="Inter, system-ui, sans-serif"
                fontWeight="700"
                fontSize="12.5"
              >
                I
              </text>
            </svg>
            Public catalog API only
          </div>
        </footer>
      </div>
    </>
  );
}
